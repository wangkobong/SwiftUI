//
//  AppDelegate.swift
//  TeamPlan
//
//  Created by sungyeon kim on 2023/02/05.
//

import Foundation
import SwiftUI

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        Thread.sleep(forTimeInterval: 1.5)
        return true
    }
}
